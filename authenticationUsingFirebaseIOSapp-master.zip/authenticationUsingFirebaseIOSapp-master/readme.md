## Here are some pictures of our app



### 1. **Welcome page**  
   ![Welcome page](welcomePage.jpg)

### 2. **Signup page**  
   ![Signup page](signup.jpg)

### 3. **Login page**  
   ![Login page](login.jpg)

### 4. **Sucessful login and  reading username  from firebase firestore**  
   ![Sucessful login](successfulLogin.jpg)

### 5. **Firebase users**  
   ![Firebase users](firebaseUsers.jpg)



Here is the  [Video Link](https://youtu.be/v2K8eru1RM0?si=Om93ggAeeiMwmfPp)
